<?php
require_once('./include/db_info.inc.php');
require_once('./include/const.inc.php');
require_once('./include/memcache.php');
require_once('./include/setlang.php');
/*
 *实现moodle用户登录功能，进行回调
 */

if (isset($_SESSION[$OJ_NAME.'_'.'user_id'])){
    //获取用户名,准备回调
    //var_dump($_SESSION);
    $username=$_SESSION[$OJ_NAME.'_'.'user_id'];
}else {
    // code...准备登录
    	$view_errors = "<a href=loginpage.php>$MSG_Login</a>";
		require("template/".$OJ_TEMPLATE."/error.php");
		exit(0);
        //Header("Location: loginpage.php");
}
if(isset($_GET['redirect_uri'])){
    //存在一个回调才继续，否则
    $redirect_uri=$_GET['redirect_uri'];
    $_SESSION[$OJ_NAME.'_'.'moodle_url']=$_GET['redirect_uri'];
    //echo $redirect_uri;
    //回调回去进行登录
    $code=uuid();
    //使用post传递参数到moodle中
    $res=Data_to_moodle($redirect_uri,$code,$username);
    //var_dump($res);
    //echo $code;
    header("Location: {$redirect_uri}?code=$code");
    exit();
}

die();


function uuid()  
{  
$chars = md5(uniqid(mt_rand(), true));  
$uuid = substr ( $chars, 0, 8 ) . '-'
        . substr ( $chars, 8, 4 ) . '-' 
        . substr ( $chars, 12, 4 ) . '-'
        . substr ( $chars, 16, 4 ) . '-'
        . substr ( $chars, 20, 12 );  
return $uuid ;  
}
//向moodle发送一个API数据包，使用post参数传递，安全
function Data_to_moodle($url,$code,$username){
    //$url = 'https://www.example.com/';
    $data = array('code' => $code, 'username' => $username);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}
?>